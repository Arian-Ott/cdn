<?php

session_write_close();
header("Location: ../../");