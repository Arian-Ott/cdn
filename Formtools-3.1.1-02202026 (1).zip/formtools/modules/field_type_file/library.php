<?php

require_once(__DIR__ . "/code/Hooks.class.php");
require_once(__DIR__ . "/code/Module.class.php");
require_once(__DIR__ . "/code/Settings.class.php");
