<?php


namespace FormTools;

class Constants
{

}
