<?php

header("Location: ../");
